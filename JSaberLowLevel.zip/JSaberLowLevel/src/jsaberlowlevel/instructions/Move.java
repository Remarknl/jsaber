package jsaberlowlevel.instructions;

public class Move implements Instruction {

    public Move(long X_OFFSET, long Y_OFFSET) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     

    @Override
    public void execute() {
        
    }
}
