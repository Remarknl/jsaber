/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsaberlowlevel.instructions;

/**
 *
 * @author rgi20802
 */
public class Laser implements Instruction {

    public Laser() {
        
    }
    
    
    @Override
    public void execute() {
        
    }
    
}
