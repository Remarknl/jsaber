package jsaberlowlevel.instructions;

public interface Instruction {
    void execute();
}
